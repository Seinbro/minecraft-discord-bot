require('dotenv').config();
const mineflayer = require('mineflayer');
const { Client, GatewayIntentBits } = require('discord.js');

// إعداد Discord
const discordClient = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

discordClient.once('ready', () => {
  console.log(`✅ Discord bot logged in as ${discordClient.user.tag}`);
});

// إنشاء البوت داخل Minecraft
const bot = mineflayer.createBot({
  host: process.env.MINECRAFT_HOST,
  port: parseInt(process.env.MINECRAFT_PORT),
  username: process.env.MINECRAFT_USERNAME,
});

bot.on('spawn', () => {
  console.log("✅ Minecraft bot has spawned.");
});

// تفاعل البوت مع الشات في Minecraft
bot.on('chat', (username, message) => {
  if (username === bot.username) return;
  console.log(`[MC] ${username}: ${message}`);
});

// الأوامر من Discord إلى Minecraft
discordClient.on('messageCreate', message => {
  if (message.author.bot) return;

  const content = message.content.toLowerCase();

  if (content === '!sayhi') {
    bot.chat('Hello from Discord!');
    message.reply('✅ قلت Hello داخل Minecraft!');
  }

  if (content === '!jump') {
    bot.setControlState('jump', true);
    setTimeout(() => bot.setControlState('jump', false), 1000);
    message.reply('🦘 قفز البوت داخل اللعبة!');
  }
});

discordClient.login(process.env.DISCORD_TOKEN);
